from django.apps import AppConfig


class InfotrackConfig(AppConfig):
    name = 'InfoTrack'
