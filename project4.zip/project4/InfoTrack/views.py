from django.urls import reverse
from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm, UserChangeForm
from InfoTrack.forms import EditProfileForm,RegistrationForm
from django.contrib.auth.models import User
from django.contrib.auth.forms import PasswordChangeForm
from django.contrib.auth import update_session_auth_hash
from django.contrib.auth.decorators import login_required
from django.utils import timezone
# Create your views here.
from .models import User, Comment, Post,UserProfile
"""
def test(request):
    if request.method == 'POST':
        form = ProfileForm(request.POST)
        if form.is_valid():
            pass  # does nothing, just trigger the validation
    else:
        form = ProfileForm()
    return render(request, 'accounts/test_form.html', {'form': form})
"""

def homepage(request):
    #return render(request,"accounts/test_form.html")
    return render(request,"homepage.html")

#question 1: how to correctly save the form?
#how to correctly create an edit form so call correctly edit the form?
def register(request):
    if request.method == "POST":
        form = RegistrationForm(request.POST)
        if form.is_valid():
            #profile = form.save(commit = False)
            #profile.user = request.user
            form.save()
            return redirect(reverse('InfoTrack:homepage'))
    else:
        form = RegistrationForm()
    args = {"form":form}
    return render(request, 'accounts/reg_form.html',args)

@login_required
def viwe_profile(request):
    args = {"user": request.user}
    return render(request, 'accounts/profile.html', args)

@login_required
def edit_profile(request):
    if request.method =="POST":
        ###pass user object by instance= request.user
        #change from userchangeform to EditProfileForm
        form = EditProfileForm(request.POST, instance = request.user)
        if form.is_valid():
            form.save()
            return redirect(reverse('InfoTrack:view_profile'))
    else:
        form = EditProfileForm(instance = request.user)
        args = {"form":form}
        return render(request,"accounts/edit_profile.html",args)

def change_password(request):
    if request.method =="POST":
        form = PasswordChangeForm(data = request.POST, user = request.user)
        if form.is_valid():
            form.save()
            ###log_in and stay in the session even change the password
            update_session_auth_hash(request, form.user)
            return redirect(reverse('InfoTrack:view_profile'))
        else:
            return redirect(reverse('InfoTrack:change_password'))
    else:
        form = PasswordChangeForm(user = request.user)
        args = {"form":form}
        return render(request,"accounts/change_password.html",args)

@login_required
def clubinfo(request):
    try:
        posts = Post.objects.order_by('time')[:6]
    except Post.DoesNotExist:
        raise Http404("Post does not exist")

    args ={ 
        'posts0' : posts[0],
        'posts1' : posts[1],
        'posts2' : posts[2],
        'posts3' : posts[3],
        'posts4' : posts[4],
        'posts5' : posts[5],
        }
    return render(
        request,
        'sections/clubinfo.html',
        args
        )

@login_required
def courseinfo(request):
    # Render the HTML template index.html with the data in the context variable
    try:
        posts = Post.objects.order_by('time')[:6]
    except Post.DoesNotExist:
        raise Http404("Post does not exist")

    args ={ 
        'posts0' : posts[0],
        'posts1' : posts[1],
        'posts2' : posts[2],
        'posts3' : posts[3],
        'posts4' : posts[4],
        'posts5' : posts[5],
        }
    return render(
        request,
        'sections/courseinfo.html',
        args
        )

@login_required
def freeride(request):
    # Render the HTML template index.html with the data in the context variable
    try:
        posts = Post.objects.order_by('time')[:6]
    except Post.DoesNotExist:
        raise Http404("Post does not exist")

    args ={ 
        'posts0' : posts[0],
        'posts1' : posts[1],
        'posts2' : posts[2],
        'posts3' : posts[3],
        'posts4' : posts[4],
        'posts5' : posts[5],
        }
    return render(
        request,
        'sections/freeride.html',
        args
        )
@login_required
def privatetutor(request):
    # Render the HTML template index.html with the data in the context variable
    try:
        posts = Post.objects.order_by('time')[:6]
    except Post.DoesNotExist:
        raise Http404("Post does not exist")

    args ={ 
        'posts0' : posts[0],
        'posts1' : posts[1],
        'posts2' : posts[2],
        'posts3' : posts[3],
        'posts4' : posts[4],
        'posts5' : posts[5],
        }
    return render(
        request,
        'sections/privatetutor.html',
        args
        )

@login_required
def rentinfo(request):
    # Render the HTML template index.html with the data in the context variable
    try:
        posts = Post.objects.order_by('time')[:6]
    except Post.DoesNotExist:
        raise Http404("Post does not exist")

    args ={ 
        'posts0' : posts[0],
        'posts1' : posts[1],
        'posts2' : posts[2],
        'posts3' : posts[3],
        'posts4' : posts[4],
        'posts5' : posts[5],
        }
    return render(
        request,
        'sections/rentinfo.html',
        args
        )


@login_required
def funstory(request):
    # Render the HTML template index.html with the data in the context variable
    try:
        posts = Post.objects.order_by('time')[:6]
    except Post.DoesNotExist:
        raise Http404("Post does not exist")

    args ={ 
        'posts0' : posts[0],
        'posts1' : posts[1],
        'posts2' : posts[2],
        'posts3' : posts[3],
        'posts4' : posts[4],
        'posts5' : posts[5],
        }
    return render(
        request,
        'sections/funstory.html',
        args
        )

'''
New Functions Below:
'''

@login_required
def post_list(request):
    posts = Post.objects.all()
    paginator = Paginator(posts, 4)
    page = request.GET.get('page')
    try:
        post_page = paginator.page(page)
    except PageNotAnInteger:
        post_page = paginator.page(1)
    except EmptyPage:
        post_page = paginator.page(paginator.num_pages)
    return render(request, 'posts/post_list.html', {'posts': post_page})

@login_required
def post_detail(request, pk):
    post = Post.objects.get(pk=pk)
    args = {'post': post}
    return render(request, 'posts/post_detail.html', args)

@login_required
def add_post(request):
    if request.method == 'POST':
        form = PostForm(request.POST)
        if form.is_valid():
            post = form.save(commit=False)
            post.time = timezone.now()
            post.user = request.user
            post.save()
            return redirect('InfoTrack:post_detail', pk=post.pk)       
    else:
        form = PostForm()
    return render(request, 'posts/add_post.html', {'form': form})

@login_required
def post_edit(request, pk):
    post = get_object_or_404(Post, pk=pk)
    if request.method == "POST":
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            post = form.save(commit=False)
            post.time = timezone.now()
            post.save()
            return redirect('posts/post_detail', pk=post.pk)
    else:
        form = PostForm(instance=post)
    return render(request, 'posts/post_edit.html', {'form': form})

@login_required
def post_search(request):
    if request.method == 'GET':
        keyword = request.GET.get('search_box', None)
        if not keyword:
            return redirect('InfoTrack:post_list')
        posts = Post.objects.filter(Q(context__contains = keyword) | Q(title__contains = keyword))
        #posts = Post.objects.filter(context__contains = keyword)
        paginator = Paginator(posts, 4)
        page = request.GET.get('page')
        try:
            post_page = paginator.page(page)
        except PageNotAnInteger:
            post_page = paginator.page(1)
        except EmptyPage:
            post_page = paginator.page(paginator.num_pages)
        return render(request, 'posts/post_list.html', {'posts': post_page})
#####
def get(self, request):
    template_name = "accounts/test_form.html"
    users = User.objects.all()
    return render(request, self.template_name, {'users': users})
